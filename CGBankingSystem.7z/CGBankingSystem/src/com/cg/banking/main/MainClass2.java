package com.cg.banking.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

import com.cg.banking.beans.Customer;

public class MainClass2 {

	public static void main(String[] args) {
		ArrayList<Customer>customerList=new ArrayList<>();
		customerList.add(new Customer(111, "Shishir", "Reddy"));
		customerList.add(new Customer(116, "Avani", "Reddy"));
		customerList.add(new Customer(112, "shishir", "Reddy"));
		customerList.add(new Customer(121, "Harika", "Reddy"));
		customerList.add(new Customer(101, "avani", "Reddy"));
		System.out.println(customerList.get(2));
		Collections.sort(customerList);
		for (Customer customer2 : customerList) {
			System.out.println(customer2);
		}
		
	}

}
